# Oppgave: Fjerne sensitiv informasjon fra repo
Her har det sneket seg inn et passord i kildekoden. Fjern det helt fra git-historikken.