#!/bin/sh

API_URL="http://cowsay.morecode.org/say"
API_KEY="PaSsWoRd123!"

MESSAGE="This API doesnt even require a key..."

curl -H "x-api-key: $API_KEY" -X POST "$API_URL" --data-urlencode "message=$MESSAGE" --data "format=text"
