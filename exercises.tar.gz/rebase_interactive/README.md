# Oppgave: Interactive rebase
I dette repoet finnes to brancher, branch-a og branch-b. branch-a er sjekket ut.

* Se på historikken til hele repoet i ett view.

* Kjør følgende kommando: `git rebase --interactive branch-b`

Hvilke commits ser du? Kan du forklare hvorfor det er sånn?

* Gjør noen endringer (endre rekkefølge, squash, whatever)

Hva har skjedd med historikken? Prøv å svare før du sjekker.