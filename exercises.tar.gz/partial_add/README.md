# Oppgave: Splitt endringer over flere commits
Legg til endringer flere steder i fizzbuzz.py (for eksempel kommentarer).

Lag så én commit per endring.