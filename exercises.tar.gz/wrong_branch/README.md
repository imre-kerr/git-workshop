# Oppgave: Commitet på feil branch

Her har du vært litt for ivrig med commit-kommandoen! Det er bra å commite
ofte, men som regel har du lyst til å gjøre arbeidet ditt på en feature-branch
som så kan sendes til code review og merges inn i master.

Fiks opp slik at den siste commiten er på en egen branch, og master er i sync
med origin/master.
