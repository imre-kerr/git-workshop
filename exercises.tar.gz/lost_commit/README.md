# Oppgave: Mistet commit
Her er det en commit som har blitt borte i historikken! Finn den igjen, og fiks
historikken til master slik at alle commits (Initial, A, B, C, D, E) er med.

## Bonusoppgave
Ha alle commits i (alfabetisk) rekkefølge, uten merge commits.
